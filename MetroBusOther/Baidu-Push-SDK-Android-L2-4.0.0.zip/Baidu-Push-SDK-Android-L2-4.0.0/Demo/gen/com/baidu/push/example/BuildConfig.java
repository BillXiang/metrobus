/** Automatically generated file. DO NOT MODIFY */
package com.baidu.push.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}